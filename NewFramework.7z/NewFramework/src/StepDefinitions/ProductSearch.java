package StepDefinitions;
import org.junit.Assert;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import PageObjects.CustomMethods;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ProductSearch extends BaseClass{
	WebDriver driver;
	CustomMethods customMethod = new CustomMethods();
    
	Hook hook =  new Hook();
	public ProductSearch() {
		this.driver = hook.setUp();
	}
	
	@Given("^visit Ebay url$")
	public void open_the_Browser(){
		driver.get("http://ebay.com");	
	}
	
	@And("^Navigate to search page with category (.*) and subcategory (.*)$")
	public void searchCategory(String category, String subCategory) {
		WebElement elementCategory = driver.findElement(By.linkText(category));
		customMethod.waitForPageLoad(driver);
		customMethod.hoverElement(driver,elementCategory);
		customMethod.waitForPageLoad(driver);
		WebElement elementSub = driver.findElement(By.xpath("(//li/a[contains(.,'"+subCategory+"')])[1]"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		customMethod.jsClick(driver,elementSub);
		
	}
	
	@And("^Click on Shop with Category (.*)$")
	public void clickOnShopWithCategory(String category){
		driver.findElement(By.linkText(category)).click();
		customMethod.waitForPageLoad(driver);
		driver.findElement(By.xpath("(//span[contains(.,'See All')])[1]")).click();
		
	}
	
	@And("^Click On Filters (.*) and (.*) and (.*)$")
	public void clickFilterElements(String filterType1, String filterType2, String filterType3){
		driver.findElement(By.xpath("(//span[contains(.,'"+filterType1+"')])[1]")).click();
		customMethod.waitForPageLoad(driver);
		driver.findElement(By.xpath("(//span[contains(.,'"+filterType2+"')])[1]")).click();
		customMethod.waitForPageLoad(driver);
		driver.findElement(By.xpath("(//span[contains(.,'"+filterType3+"')])[1]")).click();
		customMethod.waitForPageLoad(driver);
		driver.findElement(By.xpath("//button[contains(.,'Apply')]")).click();
		customMethod.waitForPageLoad(driver);
		
	}
	
	
	@And("^Verify the Filters (.*) and (.*) and (.*)$")
	public void verifyFilterElements(String filterType1, String filterType2, String filterType3){
		driver.findElement(By.xpath("(//span[contains(.,'filters applied')])[1]")).click();
		customMethod.waitForPageLoad(driver);
		driver.findElement(By.xpath("(//span[contains(.,'"+filterType1+"')])[1]")).isDisplayed();
		driver.findElement(By.xpath("(//span[contains(.,'"+filterType2+"')])[1]")).isDisplayed();
		driver.findElement(By.xpath("(//span[contains(.,'"+filterType3+"')])[1]")).isDisplayed();
	}
	
	@When("^Search for Product (.*) with Category (.*)$")
	public void searchForCategory(String product, String category){
		driver.findElement(By.name("_nkw")).sendKeys(product);
		driver.findElement(By.id("gh-cat-box")).click();
		WebElement dropDownCategory = driver.findElement(By.id("gh-cat"));
		customMethod.selectByVisibleText(dropDownCategory,category);
		driver.findElement(By.id("gh-btn")).click();
		customMethod.waitForPageLoad(driver);
	}
	
	
	@When("^Verify the Product (.*)$")
	public void verifyThePrpoduct(String product){
		String productActual = driver.findElement(By.xpath("(//div[contains(@class,'s-item__title')]//span[contains(@role,'heading')])[2]")).getText();
		System.out.print(productActual);
		Assert.assertTrue("Mismatch for Seacrh",productActual.contains(product));
	}
	
	@After
	public void runAfterScenario() {
		if(driver != null) {
			driver.quit();
		}
	}
	

}
