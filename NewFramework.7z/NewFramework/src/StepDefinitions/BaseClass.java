package StepDefinitions;

import org.openqa.selenium.WebDriver;

public class BaseClass {
	public  WebDriver driver = null;
}
