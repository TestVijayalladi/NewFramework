package StepDefinitions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;


public class Hook{
	WebDriver driver;
	BaseClass base = new BaseClass();
	
	public Hook() {
		this.driver = base.driver;
	}
	
	public WebDriver setUp() {
		System.setProperty("webdriver.chrome.driver","D:\\ChromeDriver\\chromedriver.exe");      
		driver = new ChromeDriver();
		return driver;
	}
	

}
