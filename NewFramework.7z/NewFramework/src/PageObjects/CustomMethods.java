package PageObjects;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import StepDefinitions.Hook;

public class CustomMethods{
	
	Hook hook = new Hook();

	public void hoverElement(WebDriver driver,WebElement element) {
		Actions action = new Actions(driver);
		action.moveToElement(element).build().perform();
	}
	
	public void waitForPageLoad(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		wait.until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete")); 
	}
	
	public void jsClick(WebDriver driver, WebElement element){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
		js.executeScript("arguments[0].click();", element);
		
	}
	
	public void jsClickForElementText(WebDriver driver, String text){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("var element = document.querySelector('locator'); element.value = "+text);
	}
	public void selectByVisibleText(WebElement element,String text){
	    Select drpDown = new Select(element);
	    drpDown.selectByVisibleText(text);
	}
	

}
